export const GlobalFileNames = {
	apiConversationHistory: "api_conversation_history.json",
	uiMessages: "ui_messages.json",
	glamaModels: "glama_models.json",
	openRouterModels: "openrouter_models.json",
	requestyModels: "requesty_models.json",
	mcpSettings: "cline_mcp_settings.json",
	unboundModels: "unbound_models.json",
}
