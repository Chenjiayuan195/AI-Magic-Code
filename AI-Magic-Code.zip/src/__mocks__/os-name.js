function osName() {
	return "macOS"
}

module.exports = osName
module.exports.default = osName
