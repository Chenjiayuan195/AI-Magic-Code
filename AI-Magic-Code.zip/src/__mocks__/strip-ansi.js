function stripAnsi(string) {
	// Simple mock that just returns the input string
	return string
}

module.exports = stripAnsi
module.exports.default = stripAnsi
