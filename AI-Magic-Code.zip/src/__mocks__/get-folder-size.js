module.exports = async function getFolderSize() {
	return {
		size: 1000,
		errors: [],
	}
}

module.exports.loose = async function getFolderSizeLoose() {
	return {
		size: 1000,
		errors: [],
	}
}
