# Magic Code Changelog

## [1.0.0] - 2025-03-10
构建webAI助手，更新提示词